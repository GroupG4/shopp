package com.example.Eurekhaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekhaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
