package com.payment.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Payment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
